"""
Shu jadvallar ustida querylar yozishni o'rganamiz.

1. Userda jadvalidagi hamma foydalanuvchilarni olib bering
2. User tabledagi hamma foydalanuvchilarni ismlarini olib bering.
3. User tabledagi hamma foydalanuvchuning ism familiyani olib bering faqat bu safar column
   name lari ism, familiya bolib qaytsin
4. User tableda ismining ichida ali sozi borlarini olib berish
5. Post tabledagi likelari soni 10  tadan ko'p bo'lgan postlarni olib bering
6. Postlar tabledagi hamma postlarni olib bering
7. Postlar tableda nechta post borlini topib bering
8. User tableda bir xil ismlilarni olib tashlagan holda nech xil ismli user borligini olib bering
9. Post tabledan likelari soni 10 va 20 o'rtasidagi barcha postlarni olib bering
10. Ismlari shu tupleni ichida bor bo'lgan odamlarni olib bering. ('Sanjarbek', 'vali', 'ali)
"""